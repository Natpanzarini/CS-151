Name:
  Natalio Panzarini

How many hours did you spend on the exam?
  4 hours.
